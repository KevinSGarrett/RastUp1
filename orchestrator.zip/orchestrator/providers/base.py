# orchestrator/providers/base.py
from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Protocol, runtime_checkable

# Env toggle used by tests/CI to stub out provider calls
STUB_ENV = "ORCHESTRATOR_LLM_STUB"


@dataclass
class LLMResponse:
    model: str
    content: str
    role: str = "assistant"
    finish_reason: str = "stop"
    usage: Optional[Dict[str, int]] = None
    raw: Any = None

    @property
    def text(self) -> str:
        val = getattr(self, 'content', None)
        return _normalize_llm_text(val)

    def __str__(self) -> str:
        return self.text


@runtime_checkable
class LLMProvider(Protocol):
    """
    Minimal protocol the orchestrator/tests expect.
    Concrete providers (OpenAIProvider, AnthropicProvider) should implement at
    least one of: `chat` (messages) or `complete` (single prompt).
    """
    model: str

    def chat(self, messages: List[Dict[str, str]], **kwargs: Any) -> LLMResponse: ...
    def complete(self, prompt: str, **kwargs: Any) -> LLMResponse: ...


def stub_enabled() -> bool:
    v = os.getenv(STUB_ENV, "0").lower()
    return v in ("1", "true", "yes", "on")


def _derive_content_from_payload(payload: Any) -> str:
    """
    Try to derive a reasonable stub content string from various payload shapes.
    Supports:
      - dicts with 'content' or 'prompt'
      - list-of-dicts chat messages: uses the last item's 'content'
      - anything else -> str(payload)
    """
    # dict payload with typical fields
    if isinstance(payload, dict):
        return str(payload.get("content") or payload.get("prompt") or "")

    # list-of-dicts chat messages
    if isinstance(payload, list):
        # Best-effort: find last dict with a 'content' field
        for item in reversed(payload):
            if isinstance(item, dict) and isinstance(item.get("content"), str):
                return item["content"]
        # Fallback to string form of the list
        return str(payload)

    # generic fallback
    return str(payload)


def _stub_reply(
    input_payload: Any,
    prompt: Optional[str] = None,
    *,
    model: str = "stub",
    content: Optional[str] = None,
    role: str = "assistant",
    extra: Optional[Dict[str, Any]] = None,
) -> LLLMResponse:
    """Backward-compatible shim.

    Accepts both:
      - _stub_reply(input_payload, ...)
      - _stub_reply(model_name, prompt)

    Notes:
      - If `content` is not provided, it is derived from `prompt` (if present)
        or the `input_payload`.
      - `extra` is accepted for call-site compatibility but only forwarded if
        the current LLMResponse supports such a field (keeps backward/forward
        compatibility when the dataclass changes across versions).
    """
    # If a second positional arg was provided, treat it as the content/prompt.
    if content is None and prompt is not None:
        content = prompt

    # Derive content from payload if still not provided.
    if content is None:
        content = _derive_content_from_payload(input_payload)

    # Try to infer a model name from the first positional arg if it looks like one.
    selected_model = model
    if prompt is not None and model == "stub" and not isinstance(input_payload, dict):
        selected_model = str(input_payload)

    # Filter kwargs to what LLMResponse actually accepts (to play nice across versions).
    try:
        from inspect import signature
        allowed = set(signature(LLMResponse).parameters)
    except Exception:
        allowed = {"model", "content", "role"}

    payload: Dict[str, Any] = {"model": selected_model, "content": content, "role": role}

    # Provide a friendly default finish_reason if supported by this LLMResponse.
    if "finish_reason" in allowed and "finish_reason" not in payload:
        payload["finish_reason"] = "stop"

    # Only include 'extra' if the dataclass supports it (future-proofing).
    if extra is not None and "extra" in allowed:
        payload["extra"] = extra

    # Construct with only the allowed fields
    final_payload = {k: v for k, v in payload.items() if k in allowed}
    return LLMResponse(**final_payload)


__all__ = ["LLMResponse", "LLMProvider", "_stub_reply", "stub_enabled"]

# --- injected: normalize LLM content to plain text ---
from typing import Any

def _normalize_llm_text(val: Any) -> str:
    """Best-effort conversion of mixed provider payloads to plain text."""
    try:
        import types  # noqa: F401
    except Exception:
        pass

    if val is None:
        return ""
    if isinstance(val, str):
        return val

    # Lists of content parts
    if isinstance(val, list):
        parts = []
        for item in val:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict):
                t = item.get("text")
                if isinstance(t, str):
                    parts.append(t)
                else:
                    c = item.get("content")
                    if c is not None:
                        parts.append(_normalize_llm_text(c))
            else:
                try:
                    parts.append(str(item))
                except Exception:
                    pass
        return "".join(parts)

    # Dicts: look for common keys
    if isinstance(val, dict):
        for k in ("text", "content", "message", "output", "response"):
            if k in val:
                return _normalize_llm_text(val[k])
        try:
            return str(val)
        except Exception:
            return ""

    # Objects with string-like attributes
    for attr in ("text", "content", "message", "output", "response"):
        try:
            v = getattr(val, attr)
        except Exception:
            v = None
        if v is not None:
            return _normalize_llm_text(v)

    # Last resort
    try:
        return str(val)
    except Exception:
        return ""
# --- end injected normalize ---
