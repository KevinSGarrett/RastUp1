# Orchestrator Review

## Assistant‑Manager (Anthropic)

anthropic [stub:cca446e19804]

## Primary Review (OpenAI)

openai [stub:cca446e19804]

## Final Orchestrator Decision (OpenAI)

openai.finalize [stub:c4719a04ef02]
